package com.capgemini.store.controllers;

public class URIController {

}
