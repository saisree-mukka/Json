package com.example.controller;

import java.util.List;
import java.util.Arrays;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.example.beans.Customer;
import com.example.beans.Message;
import com.example.beans.Orders;
import com.example.beans.Product;

@Controller
public class JspController {

	@RequestMapping(value="/")
	public String showWelcomePage( ModelMap model){
		
		RestTemplate restTemplate = new RestTemplate();
		Customer message = restTemplate.getForObject("http://localhost:9898/passwordRetrieve.json", Customer.class);
		System.out.println(message);
		model.put("customer", message);
		return "successmessage_forgetPassword";
	}
//	
//	@RequestMapping(value="/")
//	public String showWelcomePage( ModelMap model){
//		
//		RestTemplate restTemplate = new RestTemplate();
//		Customer message = restTemplate.getForObject("http://localhost:9898/updateProfile.json", Customer.class);
//		System.out.println(message);
//		model.put("customer", message);
//		return "updateProfile";
//	}
	

//	@RequestMapping(value="/")
//	public String showWelcomePage( ModelMap model){
//		
//		RestTemplate restTemplate = new RestTemplate();
//		Customer message = restTemplate.getForObject("http://localhost:9898/viewProfile.json", Customer.class);
//		System.out.println(message);
//		model.put("customer", message);
//		return "viewProfile";
//	}
	
//	@RequestMapping(value="/")
//	public String showWelcomePage( ModelMap model){
//		
//		RestTemplate restTemplate = new RestTemplate();
//		Customer message = restTemplate.getForObject("http://localhost:9898/myOrders.json", Customer.class);
//		System.out.println(message);
//		model.put("customer", message);
//		return "myOrders";
//	}
	
//	
//	@RequestMapping(value="/")
//	public String showWelcomePage( ModelMap model){
//		
//		RestTemplate restTemplate = new RestTemplate();
//		Customer message = restTemplate.getForObject("http://localhost:9898/securityQuestion.json", Customer.class);
//		System.out.println(message);
//		model.put("customer", message);
//		return "securityQuestion";
//	}
	
	
//	@RequestMapping(value="/")
//	public String showWelcomePage( ModelMap model){
//		
//		RestTemplate restTemplate = new RestTemplate();
//		Product message = restTemplate.getForObject("http://localhost:9898/wishlist.json", Product.class);
//		System.out.println(message);
//		model.put("product", message);
//		return "wishlist";
//	}
	
//	@RequestMapping(value="/")
//	public String showWelcomePage( ModelMap model){
//		
//		RestTemplate restTemplate = new RestTemplate();
//		Product message = restTemplate.getForObject("http://localhost:9898/mainDynamic.json", Product.class);
//		System.out.println(message);
//		model.put("product", message);
//		return "mainDynamic";
//	}
}

